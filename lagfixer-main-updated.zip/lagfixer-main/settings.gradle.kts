pluginManagement {
    repositories {
        gradlePluginPortal()
        maven("https://repo.papermc.io/repository/maven-public/")
    }
}

plugins {
    id("org.gradle.toolchains.foojay-resolver-convention") version "0.9.0"
}

rootProject.name = "LagFixer"

include("plugin")

include("nms:v1_16_R3")
include("nms:v1_17_R1")
include("nms:v1_18_R2")
include("nms:v1_19_R3")
include("nms:v1_20_R1")
include("nms:v1_20_R2")
include("nms:v1_20_R3")
include("nms:v1_20_R4")
include("nms:v1_21_R1")
include("nms:v1_21_R2")
include("nms:v1_21_R3")
include("nms:v1_21_R4")
include("nms:v1_21_R5")
include("nms:v1_21_R6")
include("nms:v1_21_R7")
include("nms:v26_1")
include("nms:v26_2")

include("support:paper")
include("support:spigot")
include("support:common")