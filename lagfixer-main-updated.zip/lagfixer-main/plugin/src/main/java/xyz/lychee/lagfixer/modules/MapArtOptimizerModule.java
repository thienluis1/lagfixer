package xyz.lychee.lagfixer.modules;

import org.bukkit.Chunk;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemFrame;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.MapMeta;
import org.bukkit.map.MapView;
import org.bukkit.scheduler.BukkitTask;
import xyz.lychee.lagfixer.LagFixer;
import xyz.lychee.lagfixer.managers.ModuleManager;
import xyz.lychee.lagfixer.managers.SupportManager;
import xyz.lychee.lagfixer.objects.AbstractModule;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * Những bức tường map-art dùng hàng trăm/nghìn khung tranh chứa bản đồ khiến server phải render
 * lại bản đồ mỗi tick cho từng người chơi gần đó. Module này phát hiện bản đồ nào đã đứng yên
 * qua nhiều lần quét (không đổi nội dung) rồi khóa lại (MapView#setLocked) để dừng việc render
 * lặp lại. Hình ảnh hiển thị giữ nguyên 100%, chỉ dừng tính toán lại phần đã ổn định. Nếu bản đồ
 * trong khung tranh bị thay đổi, module tự mở khóa để bản đồ mới hiển thị bình thường trở lại.
 */
public class MapArtOptimizerModule extends AbstractModule {
    private final Map<UUID, State> states = new HashMap<>();

    private boolean lock;
    private boolean disableTracking;
    private int scanInterval;
    private int stableScansRequired;

    private BukkitTask task;

    public MapArtOptimizerModule(LagFixer plugin, ModuleManager manager) {
        super(plugin, manager, AbstractModule.Impact.MEDIUM, "MapArtOptimizer",
                new String[]{
                        "Đóng băng việc render lại các bản đồ đã đứng yên trong khung tranh (map-art).",
                        "Giúp giảm tải rõ rệt cho tường tranh pixel-art lớn dùng nhiều khung + bản đồ.",
                        "Hình ảnh hiển thị không đổi, chỉ dừng việc tính toán lại phần đã ổn định.",
                        "Tự động mở khóa ngay khi bản đồ trong khung tranh bị thay đổi hoặc gỡ bỏ."
                }, "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYTlkODA2Yjc1ZWM5NTAwNmM1ZWMzODY2YzU0OGM1NTcxYWYzZTc4OGM3ZDE2MjllZGU2NGJjMWI3NDg4NTljZCJ9fX0=");
    }

    private void scan() {
        Map<UUID, State> updated = new HashMap<>();

        for (var world : this.getAllowedWorlds()) {
            for (Chunk chunk : world.getLoadedChunks()) {
                for (Entity entity : chunk.getEntities()) {
                    if (!(entity instanceof ItemFrame frame)) continue;

                    ItemStack item = frame.getItem();
                    if (item.getType() != Material.FILLED_MAP) continue;
                    if (!(item.getItemMeta() instanceof MapMeta meta) || !meta.hasMapView()) continue;

                    MapView view = meta.getMapView();
                    if (view == null) continue;

                    int mapId = view.getId();
                    State previous = this.states.get(entity.getUniqueId());

                    if (previous != null && previous.mapId == mapId) {
                        previous.stableScans++;
                    } else {
                        if (previous != null && previous.optimized) {
                            this.restore(view);
                        }
                        previous = new State(mapId, 0, false);
                    }

                    if (!previous.optimized && previous.stableScans >= this.stableScansRequired) {
                        this.optimize(view);
                        previous.optimized = true;
                    }

                    updated.put(entity.getUniqueId(), previous);
                }
            }
        }

        this.states.clear();
        this.states.putAll(updated);
    }

    private void optimize(MapView view) {
        if (this.lock) view.setLocked(true);
        if (this.disableTracking) {
            view.setTrackingPosition(false);
            view.setUnlimitedTracking(false);
        }
    }

    private void restore(MapView view) {
        view.setLocked(false);
        view.setTrackingPosition(true);
    }

    @Override
    public void load() {
        long interval = Math.max(1, this.scanInterval);
        this.task = SupportManager.getInstance().getFork().runTimer(false, this::scan, interval, interval, TimeUnit.SECONDS);
    }

    @Override
    public boolean loadConfig() {
        this.lock = this.getSection().getBoolean("lock");
        this.disableTracking = this.getSection().getBoolean("disable_tracking");
        this.scanInterval = this.getSection().getInt("scan_interval");
        this.stableScansRequired = Math.max(1, this.getSection().getInt("stable_scans_required"));
        return true;
    }

    @Override
    public void disable() {
        if (this.task != null) this.task.cancel();
        this.states.clear();
    }

    private static class State {
        private int mapId;
        private int stableScans;
        private boolean optimized;

        private State(int mapId, int stableScans, boolean optimized) {
            this.mapId = mapId;
            this.stableScans = stableScans;
            this.optimized = optimized;
        }
    }
}
