package xyz.lychee.lagfixer.hooks;

import lombok.Getter;
import me.lucko.spark.api.Spark;
import me.lucko.spark.api.SparkProvider;
import me.lucko.spark.api.statistic.StatisticWindow;
import me.lucko.spark.api.statistic.misc.DoubleAverageInfo;
import me.lucko.spark.api.statistic.types.DoubleStatistic;
import me.lucko.spark.api.statistic.types.GenericStatistic;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.server.ServerLoadEvent;
import org.bukkit.scheduler.BukkitTask;
import xyz.lychee.lagfixer.LagFixer;
import xyz.lychee.lagfixer.managers.ErrorsManager;
import xyz.lychee.lagfixer.managers.HookManager;
import xyz.lychee.lagfixer.managers.SupportManager;
import xyz.lychee.lagfixer.objects.AbstractHook;
import xyz.lychee.lagfixer.objects.ResourceMonitor;

import java.util.concurrent.TimeUnit;

@Getter
public class SparkHook extends AbstractHook implements Listener {
    private BukkitTask task;

    public SparkHook(LagFixer plugin, HookManager manager) {
        super(plugin, "spark", manager);
    }

    @Override
    public void load() {
        Bukkit.getPluginManager().registerEvents(this, this.getPlugin());
        this.task = SupportManager.getInstance().getFork().runTimer(false, () -> {
            if (ErrorsManager.getInstance().isEnabled() && Bukkit.getOnlinePlayers().size() > 20) {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "spark profiler open");
            }
        }, 1L, 1L, TimeUnit.HOURS);
    }

    @Override
    public void disable() {
        HandlerList.unregisterAll(this);
        if (this.task != null) {
            this.task.cancel();
        }
    }

    @EventHandler
    public void onLoad(ServerLoadEvent event) {
        SupportManager support = SupportManager.getInstance();
        support.getResourceMonitor().stop();

        SparkMonitor monitor = new SparkMonitor();
        monitor.start();
        support.setResourceMonitor(monitor);
    }

    static class SparkMonitor extends ResourceMonitor {
        private final Spark spark = SparkProvider.get();

        @Override
        public double cpuProcess() {
            return this.spark.cpuProcess().poll(StatisticWindow.CpuUsage.SECONDS_10) * 100.0;
        }

        @Override
        public double cpuSystem() {
            return this.spark.cpuSystem().poll(StatisticWindow.CpuUsage.SECONDS_10) * 100.0;
        }

        @Override
        public double tps() {
            DoubleStatistic<StatisticWindow.TicksPerSecond> tps = this.spark.tps();
            return tps == null ? 20.0 : tps.poll(StatisticWindow.TicksPerSecond.SECONDS_10);
        }

        @Override
        public double mspt() {
            GenericStatistic<DoubleAverageInfo, StatisticWindow.MillisPerTick> mspt = this.spark.mspt();
            return mspt == null ? 0.0 : mspt.poll(StatisticWindow.MillisPerTick.SECONDS_10).median();
        }
    }
}

