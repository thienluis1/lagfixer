package xyz.lychee.lagfixer.modules;

import org.bukkit.Chunk;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.LivingEntity;
import org.bukkit.scheduler.BukkitTask;
import xyz.lychee.lagfixer.LagFixer;
import xyz.lychee.lagfixer.managers.ModuleManager;
import xyz.lychee.lagfixer.managers.SupportManager;
import xyz.lychee.lagfixer.objects.AbstractModule;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * Phát hiện các thực thể trang trí (ArmorStand, ItemFrame, GlowItemFrame, Painting) không hề
 * thay đổi vị trí/hướng qua nhiều lần quét liên tiếp, rồi tắt bớt các phép tính không cần thiết
 * (va chạm, âm thanh, sát thương) của chúng. Ngay khi thực thể bị di chuyển/chỉnh sửa lại,
 * module sẽ tự động khôi phục hành vi mặc định, nên không ảnh hưởng đến công trình hay người chơi.
 */
public class DecorationOptimizerModule extends AbstractModule {
    private final Map<UUID, State> states = new HashMap<>();

    private boolean armorStands;
    private boolean itemFrames;
    private boolean glowItemFrames;
    private boolean paintings;

    private boolean disableCollisions;
    private boolean silent;
    private boolean invulnerable;

    private int scanInterval;
    private int stableScansRequired;

    private BukkitTask task;

    public DecorationOptimizerModule(LagFixer plugin, ModuleManager manager) {
        super(plugin, manager, AbstractModule.Impact.LOW, "DecorationOptimizer",
                new String[]{
                        "Tối ưu các thực thể trang trí đứng yên như giá treo giáp, khung tranh và tranh vẽ.",
                        "Sau vài lần quét không thấy thay đổi, module tắt va chạm, âm thanh và sát thương thừa.",
                        "Ngay khi thực thể được di chuyển hoặc chỉnh sửa lại, hành vi mặc định được khôi phục.",
                        "Không thay đổi hình dáng hay vị trí, chỉ giảm tải cho các công trình trưng bày lớn."
                }, "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYTJjMjA1MGVjYTBlZmRkMDMxZTY1OGI5OTZjMjM5YmY3ZGEzYWVmODY1NjEyMzY3ZWQ5ZDg5NWFlN2EwZGE5ZiJ9fX0=");
    }

    private boolean isTracked(EntityType type) {
        // So sánh theo tên chuỗi (không tham chiếu trực tiếp hằng số enum) vì
        // GLOW_ITEM_FRAME chỉ tồn tại từ 1.17 trở lên, còn plugin hỗ trợ từ 1.16.5.
        return switch (type.name()) {
            case "ARMOR_STAND" -> this.armorStands;
            case "ITEM_FRAME" -> this.itemFrames;
            case "GLOW_ITEM_FRAME" -> this.glowItemFrames;
            case "PAINTING" -> this.paintings;
            default -> false;
        };
    }

    private void scan() {
        Map<UUID, State> updated = new HashMap<>();

        for (var world : this.getAllowedWorlds()) {
            for (Chunk chunk : world.getLoadedChunks()) {
                for (Entity entity : chunk.getEntities()) {
                    EntityType type = entity.getType();
                    if (!this.isTracked(type)) continue;

                    long fingerprint = fingerprint(entity);
                    State previous = this.states.get(entity.getUniqueId());

                    if (previous != null && previous.fingerprint == fingerprint) {
                        previous.stableScans++;
                    } else {
                        if (previous != null && previous.optimized) {
                            this.restore(entity);
                        }
                        previous = new State(fingerprint, 0, false);
                    }

                    if (!previous.optimized && previous.stableScans >= this.stableScansRequired) {
                        this.optimize(entity);
                        previous.optimized = true;
                    }

                    updated.put(entity.getUniqueId(), previous);
                }
            }
        }

        this.states.clear();
        this.states.putAll(updated);
    }

    private static long fingerprint(Entity entity) {
        var loc = entity.getLocation();
        long x = Double.doubleToLongBits(loc.getX());
        long y = Double.doubleToLongBits(loc.getY());
        long z = Double.doubleToLongBits(loc.getZ());
        long yaw = Float.floatToIntBits(loc.getYaw());
        long pitch = Float.floatToIntBits(loc.getPitch());
        long hash = 17;
        hash = hash * 31 + x;
        hash = hash * 31 + y;
        hash = hash * 31 + z;
        hash = hash * 31 + yaw;
        hash = hash * 31 + pitch;
        if (entity instanceof ItemFrame frame) {
            hash = hash * 31 + frame.getItem().hashCode();
            hash = hash * 31 + frame.getRotation().hashCode();
        }
        return hash;
    }

    private void optimize(Entity entity) {
        if (entity instanceof LivingEntity living && this.disableCollisions) {
            living.setCollidable(false);
        }
        if (this.silent) {
            entity.setSilent(true);
        }
        if (this.invulnerable) {
            entity.setInvulnerable(true);
        }
    }

    private void restore(Entity entity) {
        if (entity instanceof LivingEntity living) {
            living.setCollidable(true);
        }
        entity.setSilent(false);
        entity.setInvulnerable(false);
    }

    @Override
    public void load() {
        long interval = Math.max(1, this.scanInterval);
        this.task = SupportManager.getInstance().getFork().runTimer(false, this::scan, interval, interval, TimeUnit.SECONDS);
    }

    @Override
    public boolean loadConfig() {
        this.armorStands = this.getSection().getBoolean("types.armor_stand");
        this.itemFrames = this.getSection().getBoolean("types.item_frame");
        this.glowItemFrames = this.getSection().getBoolean("types.glow_item_frame");
        this.paintings = this.getSection().getBoolean("types.painting");

        this.disableCollisions = this.getSection().getBoolean("actions.disable_collisions");
        this.silent = this.getSection().getBoolean("actions.silent");
        this.invulnerable = this.getSection().getBoolean("actions.invulnerable");

        this.scanInterval = this.getSection().getInt("scan_interval");
        this.stableScansRequired = Math.max(1, this.getSection().getInt("stable_scans_required"));
        return true;
    }

    @Override
    public void disable() {
        if (this.task != null) this.task.cancel();

        for (Map.Entry<UUID, State> entry : this.states.entrySet()) {
            if (!entry.getValue().optimized) continue;
            Entity entity = org.bukkit.Bukkit.getEntity(entry.getKey());
            if (entity != null) this.restore(entity);
        }
        this.states.clear();
    }

    private static class State {
        private long fingerprint;
        private int stableScans;
        private boolean optimized;

        private State(long fingerprint, int stableScans, boolean optimized) {
            this.fingerprint = fingerprint;
            this.stableScans = stableScans;
            this.optimized = optimized;
        }
    }
}
