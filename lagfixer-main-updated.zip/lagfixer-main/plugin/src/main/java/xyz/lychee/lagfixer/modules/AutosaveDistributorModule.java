package xyz.lychee.lagfixer.modules;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.scheduler.BukkitTask;
import xyz.lychee.lagfixer.LagFixer;
import xyz.lychee.lagfixer.managers.ModuleManager;
import xyz.lychee.lagfixer.managers.SupportManager;
import xyz.lychee.lagfixer.objects.AbstractModule;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * Theo mặc định, Bukkit/Paper tự động lưu tất cả các thế giới gần như cùng một lúc theo chu kỳ
 * autosave, gây ra một đợt giật TPS ngắn mỗi khi trùng thời điểm (đặc biệt rõ khi có nhiều thế
 * giới với công trình/khu vực dữ liệu lớn). Module này tắt autosave mặc định của từng thế giới
 * và tự lên lịch lưu so le nhau, tổng lượng dữ liệu ghi ra đĩa không đổi, chỉ trải đều thời điểm
 * lưu ra nhiều giây khác nhau để tránh dồn cục. Không xóa hay thay đổi bất kỳ dữ liệu nào.
 */
public class AutosaveDistributorModule extends AbstractModule {
    private final Set<String> managedWorlds = new HashSet<>();

    private int baseIntervalSeconds;
    private int gapSeconds;
    private boolean disableVanillaAutosave;

    private long counter;
    private BukkitTask task;

    public AutosaveDistributorModule(LagFixer plugin, ModuleManager manager) {
        super(plugin, manager, AbstractModule.Impact.LOW, "AutosaveDistributor",
                new String[]{
                        "Trải đều thời điểm autosave của từng thế giới thay vì lưu cùng lúc.",
                        "Giảm hẳn hiện tượng giật TPS định kỳ khi nhiều thế giới autosave trùng nhau.",
                        "Không thay đổi tần suất lưu tổng thể, không xóa hay chỉnh sửa dữ liệu.",
                        "Phù hợp với máy chủ có nhiều thế giới hoặc công trình/khu đất lớn."
                }, "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYmUwZmQxMDE5OWU4ZTRmY2RhYmNhZTRmODVjODU5MTgxMjdhN2M1NTUzYWQyMzVmMDFjNTZkMThiYjk0NzBkMyJ9fX0=");
    }

    private void tick() {
        this.counter++;

        List<World> worlds = new ArrayList<>(this.getAllowedWorlds());
        worlds.sort(Comparator.comparing(World::getName));

        for (int i = 0; i < worlds.size(); i++) {
            World world = worlds.get(i);

            if (this.disableVanillaAutosave && this.managedWorlds.add(world.getName())) {
                world.setAutoSave(false);
            }

            long offset = (long) i * this.gapSeconds;
            if (Math.floorMod(this.counter - offset, this.baseIntervalSeconds) == 0) {
                world.save();
            }
        }
    }

    @Override
    public void load() {
        this.counter = 0;
        this.task = SupportManager.getInstance().getFork().runTimer(false, this::tick, 1L, 1L, TimeUnit.SECONDS);
    }

    @Override
    public boolean loadConfig() {
        this.baseIntervalSeconds = Math.max(30, this.getSection().getInt("base_interval"));
        this.gapSeconds = Math.max(1, this.getSection().getInt("gap_seconds"));
        this.disableVanillaAutosave = this.getSection().getBoolean("disable_vanilla_autosave");
        return true;
    }

    @Override
    public void disable() {
        if (this.task != null) this.task.cancel();

        for (String name : this.managedWorlds) {
            World world = Bukkit.getWorld(name);
            if (world != null) world.setAutoSave(true);
        }
        this.managedWorlds.clear();
    }
}
